<?php
$msg='';
if(isset($_POST['action']) && $_POST['action']=="login")
{
   
	$memberEmail = $_POST['user_name'];
	$password = $_POST['user_password'];
	if(isset($_POST['comp_name']) && $_POST['comp_name']=='www.utharaprint.co.uk')
	{
	include('UK-CRM/includes/top_header.php');
	$tempMemberDAO = new MemberDAO();
		if($tempMemberDAO->loginMember($memberEmail, $password))
		{
		header("Location: UK-CRM/home.php");
		}
		else
		{
		$msg="Invalid username/password";
		}
	}
	
	if(isset($_POST['comp_name']) && $_POST['comp_name']=='www.utharaprint.com.au')
	{
		//echo "australia";die();
	include('AUS-CRM/includes/top_header.php');
	$tempMemberDAO = new MemberDAO();
		if($tempMemberDAO->loginMember($memberEmail, $password))
		{
		header("Location: AUS-CRM/home.php");
		}
		else
		{
		$msg="Invalid username/password";
		}
	}
	
	if(isset($_POST['comp_name']) && $_POST['comp_name']=='www.bumboomprint.co.uk')
	{
	include('bumboomprint-crm/includes/top_header.php');
	$tempMemberDAO = new MemberDAO();
		if($tempMemberDAO->loginMember($memberEmail, $password))
		{
		header("Location: bumboomprint-crm/home.php");
		}
		else
		{
		$msg="Invalid username/password";
		}
	}	
	if(isset($_POST['comp_name']) && $_POST['comp_name']=='www.utharaprint.sg')
	{
	include('singapore/includes/top_header.php');
	$tempMemberDAO = new MemberDAO();
		if($tempMemberDAO->loginMember($memberEmail, $password))
		{
		header("Location: singapore/home.php");
		}
		else
		{
		$msg="Invalid username/password";
		}
	}	
}
else 
{
                     $username = '';
                     $password = '';

                    if (isset($_COOKIE['username'])) {
                      $username = $_COOKIE['username'];
                    }

                    if (isset($_COOKIE['password'])) {
                      $password = $_COOKIE['password'];
                    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Uthara Print</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1' name='viewport'>
    <link rel="shortcut icon" href="img/admin.png"/>
    <!--start global css-->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="vendors/themify-icons.css" />
    <!-- end of global css -->
    <!--start plugin css -->
    <link rel="stylesheet" href="vendors/bootstrapValidator.min.css">
    <!--end plugin css -->
    <link type="text/css" rel="stylesheet" href="css/custom.css" />
    <link type="text/css" rel="stylesheet" href="css/pages/login.css" />

</head>

<body class="login_screen">
<!--<div class="preloader">
    <div class="preloader_img">
        <img src="img/loader.gif" class="pre_img" alt="loading...">
    </div>
</div>-->
<!--Start wrapper-->
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-4 col-md-6">
            <div class="login_box p-3">
            <div class="row m-t-20">
                <div class="col-lg-12 text-center">
                    
                    <h1 class="text-white m-t-20">Uthara Print</h1></div>
                </div>

            <div class="m-t-15">
                <form action=""  method="post" autofocus="off" id="login_from">
				<?php if($msg!=''){?><div class="col-md-12 btn btn-danger"> <?php echo $msg;?></div><br><br><?php } ?>
				<div class="form-group ">
                        <div class="input-group ">
						<select name='comp_name' class="form-control" style="background:#000;">
						
						<option value='www.utharaprint.co.uk'>www.utharaprint.co.uk</option>
						<option value='www.utharaprint.com.au'>www.utharaprint.com.au</option>
						<option value='www.bumboomprint.co.uk'>www.bumboomprint.co.uk</option>
						
						

						</select>
                       </div>
                    </div>
                    <div class="form-group ">
                        <div class="input-group ">
                            <span class="input-group-addon">
                                <i class="ti-user"></i>
                            </span>
                            <input type="text" name="user_name" class="form-control" placeholder="Enter user Name" autofocus="off"  autocomplete='off' required>
                        </div>
                    </div>
                    <div class="form-group ">
                    <div class="input-group m-t-15">
                            <span class="input-group-addon">
                                <i class="ti-lock"></i>
                            </span>
                        <input type="password" name="user_password" class="form-control" id="password" placeholder="Password" autofocus="off" autocomplete='off' required>
                    </div>
                    </div>
						<input type="hidden" name="action" value="login">
                   
                    <div class="text-center login_bottom">
                        <button type="submit" class="btn btn-success btn-block b_r_20 m-t-10 m-r-20">Sign In</button>
                    </div>
                   

                </form>
            </div>

              
            </div>
        </div>
    </div>
</div>

<!-- ./wrapper -->
<script>

</script>
</html>
