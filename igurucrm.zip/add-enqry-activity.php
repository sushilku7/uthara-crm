<?php 
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$name 		=   $_SESSION['name'];
$tmpName     =   explode(' ', $name);
$firstName   =	$tmpName[0];
$memberPost  =   $_SESSION['memberPost'];
$memberId    =   $_SESSION['memberId'];
$loginTime   = $_SESSION['lastlogin'];
$tempEnquiriesDAO        = new EnquiriesDAO();
$tempMemberDAO           = new MemberDAO();
$tempActivityTypeDAO     = new ActivityTypeDAO();
$tempEnqryActivityDAO    = new EnqryActivityDAO();

if($_POST['activityType']=="15" or $_POST['activityType']=="17" or $_POST['activityType']=="19")
{	
        $eact=$_POST['activityType'];
	$enqId = $_POST['enqry'];
	header("Location: reminders-add.php?actId=$eact&enqId=$enqId");
}
if(isset($_POST['activityType']) && $_POST['activityType']=="4" or $_POST['activityType']=="24")
{	
	$enqId = $_POST['enqry'];
        $actId=$_POST['activityType'];
        header("Location: add-enqry-activity-reply.php?actId=$actId&enqId=$enqId");
}

if(isset($_POST['activityType']) && $_POST['activityType']=="25" )
{	
	$enqId = $_POST['enqry'];
        $actId=$_POST['activityType'];
 header("Location: add-enqry-activity-reply.php?actId=$actId&enqId=$enqId");
}

if(isset($_POST['activityType']) && $_POST['activityType']=="26" )
{	
	$enqId = $_POST['enqry'];
        $actId=$_POST['activityType'];
 header("Location: add-enqry-assign-call-support.php?actId=$actId&enqId=$enqId");
}

if(isset($_POST['enqry']) && $_POST['enqry']!="")
{
	$tempEnquiriesVO = $tempEnquiriesDAO->getEnquiriesDetails($_POST['enqry']);
	$enquiryContactName = $tempEnquiriesVO->getEnqryContactName();
        $enquiryNameArr     =  explode(' ', $enquiryContactName);
        $enquiryFirstName  =$enquiryNameArr[0];
        $enquiryContactName1 = $tempEnquiriesVO->getEnqryContactName();
        $emailAddress = $tempEnquiriesVO->getEnqryEmail();
        $enquiryCompany= $tempEnquiriesVO->getEnqryCompanyName();
        $enquiryAddress1 = $tempEnquiriesVO->getEnqryAddress1();
        $enquiryAddrss2 = $tempEnquiriesVO->getEnqryAddress2();
        $enquiryTown = $tempEnquiriesVO->getEnqryTown();
        $enquiryCounty = $tempEnquiriesVO->getEnqryCounty();
        $enquiryPostCode = $tempEnquiriesVO->getEnqryPostcode();
        $allocatMemberEmail = $tempEnquiriesVO->getMemberEmail();
}

if(isset($_POST['activityType']) && $_POST['activityType']!="-1")
{	
        $SelectDefault="0";
	$activityType = $_POST['activityType'];
        $tempActivityTypeVO=$tempActivityTypeDAO->getActivityTypeDetails($activityType);
        $activityInfo=$tempActivityTypeVO->getActivityInfo();
        $activitySubject=$tempActivityTypeVO->getActivitySubject();
        if($activityType=='2')
            {
             $enquiryFirstName="Mr Olla";
             $activityInfo="Please send a sample pack to the client.".'<br />'."Client name: ".$enquiryContactName1.'<br />'."Company Name: ".$enquiryCompany.'<br />'."Address: ".$enquiryAddress1.'<br />'."Street: ".$enquiryAddrss2.'<br />'."Town/City: ".$enquiryTown.'<br />'."County: ".$enquiryCounty.'<br />'."Post code: ".$enquiryPostCode;
            }
        $activityInfo="Dear ".$enquiryFirstName.","."<br >"."<br />".$activityInfo;
}

if(!isset($_SESSION['memberId']) || !isset($_SESSION['auth']) || !$_SESSION['auth']=="yes")
{
	header("Location: index.php?msg=1");
}

if(isset($_POST['EmailDraft']) && $_POST['EmailDraft']=="Send")
{
     $memberId = $_POST['memberId'];
     $extArr = array('pdf','docx','txt','xlsx','jpg','jpeg','gif','png','bmp','tiff');
      $boundary = md5("sanwebe");
        if(isset($_FILES['attachFile']) && $_FILES['attachFile']!='')
        {
            $attachfileName=$_FILES['attachFile']['name'];
            $fileNameArray=explode('.',$_FILES['attachFile']['name']);
            
            $attachfileExt=substr($attachfileName, strrpos($attachfileName, '.')+1);
            if(in_array($attachfileExt, $extArr))
	          {
                                $alias = str_replace(' ', '_', $fileNameArray[0]);
				$alias = strtolower($alias);
				
				//$tempMemberDAO->updateMember($memberId, $alias);
			        $fileName = $alias."_".$memberId.".".$attachfileExt;
				$destination = "upload/client-draft-attach/".$fileName;
				if(move_uploaded_file($_FILES['attachFile']['tmp_name'], $destination))
				{
					$tempEnqryActivityDAO->updateAttachFile($memberId, $fileName);
                                        $SucessMsg = "Member Updated Successfully";
					
				}
                                    $file= $_FILES['attachFile']['tmp_name']  ; 
                                    $fileName=$_FILES['attachFile']['name'];
                                    $handle = fopen($file, "r");
                                    $file_size=  filesize($file);
                                    $file_type=filetype($file);
                                    $content = fread($handle, $file_size);
                                    fclose($handle);
                                    $encoded_content = chunk_split(base64_encode($content));
                                    $Attabody = "--$boundary\r\n";
                                    $Attabody .="Content-Type: $file_type; name=\"$fileName\"\r\n";
                                    $Attabody .="Content-Disposition: attachment; filename=\"$fileName\"\r\n";
                                    $Attabody .="Content-Transfer-Encoding: base64\r\n";
                                    $Attabody .="X-Attachment-Id: ".rand(1000,99999)."\r\n\r\n";
                                    $Attabody .= $encoded_content;
                          
                 }
             else 
                { 
                $error="invalid file formate";
                }
        }
        
        
        $activityId = $tempEnqryActivityDAO->insertEnqryActivity($_POST['enqryId'],$fileName,$memberId);
	$tempMemberVO = $tempMemberDAO->getMemberDetailsByMemberId($memberId);
	$memberEmail = $tempMemberVO->getMemberEmail();
        $memberName = $tempMemberVO->getMemberName();
        $memberPost = $tempMemberVO->getMemberPost();
        $signatureImg = $tempMemberVO->getSignatureImg();
        $signatureMessage = $tempMemberVO->getSignatureMsg();
        $activityInfo = $_POST['activityInfo'];
        $allocateMemberEmail = $_POST['allocateMemberEmail'];
        $infoMsg= $activityInfo;
       // $signatureMessage=strip_tags($signatureMessage);
        $infoMsg= stripslashes($infoMsg);
        $infoMsg= $infoMsg;
        $dom= explode("@",$memberEmail);
        $domain=$dom[1];
        $website="www.".$domain;
	$enqryId = $_POST['enqryId'];
        $infoMsg= stripslashes($infoMsg);
        $clientEmail=$_POST['clientEmail'];
        $subject=$_POST['msgSubject'];
       
        //Added by Anshu @ 19 Feb 2017
        $uniqueNum = Util::generateRandomStringForEmailReferenceInHeader();        
        $referenceNum = $uniqueNum."@host.utharadesigns.com";
        //End Code
        
       if(isset($_POST['activityType']) && $_POST['activityType']=='2')
        {
            $message = $infoMsg."<br />"."<br />"."<br />".$signatureMessage;
            $toEmail  ="samples4utharaprint@gmail.com";
            $headers  = "From: $companyName <".$memberEmail.">\r\n";
            $headers .= "Reply-To: " . $memberEmail . "\r\n";
            
            $headers .= "References: <$referenceNum>\r\n";
            $headers .= "Message-Id: <$referenceNum>\r\n";
            
            $headers .= "Content-Type: multipart/mixed; boundary = $boundary\r\n\r\n";
                                                //plain text
             $body = "--$boundary\r\n";
             $body .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
             $body .= "Content-Transfer-Encoding: base64\r\n\r\n";
             $body .= chunk_split(base64_encode($message));
             $body .= $Attabody;
        
        
        
            //echo $message;die();
            @mail($toEmail,$subject,$body,$headers);
            //@mail($memberEmail,$subject,$message,$headers);
            @mail($allocateMemberEmail,$subject,$body,$headers);

            $SucessMsg = "Enquiry Activity Added Successfully";
            //header("Location: view-enqry.php?id=$enqryId");    
        }
        else
        {
        
	//$activityId = $tempEnqryActivityDAO->insertEnqryActivity($_POST['enqryId'],$fileName,$memberId);
                                    $tempArr = explode(' ', $memberName);
                                    $firstName = $tempArr[0];
                                    $message   =$infoMsg."<br />"."<br />"."<br />".$signatureMessage;                               
                                    //header
                                    $headers = "MIME-Version: 1.0\r\n";
                                    $headers .= "From:".$memberEmail."\r\n";
                                    $headers .= "Reply-To: ".$memberEmail."" . "\r\n";
                                    $headers .= "References: <$referenceNum>\r\n";
                                    $headers .= "Message-Id: <$referenceNum>\r\n";
                                    $headers .= "Content-Type: multipart/mixed; boundary = $boundary\r\n\r\n";
                                    //plain text
                                    $body = "--$boundary\r\n";
                                    $body .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
                                    $body .= "Content-Transfer-Encoding: base64\r\n\r\n";
                                    $body .= chunk_split(base64_encode($message));
                                    $body .= $Attabody;
                                    //attachment
                                    

                                
                                $sent = mail($clientEmail, $subject, $body, $headers);
                                // $sent = mail($memberEmail,$subject,$body,$headers);
                                $sent = mail($allocateMemberEmail,$subject,$body,$headers);
                                //$sent = mail("anshuporwal@gmail.com",$subject,$body,$headers);
        
        
            $SucessMsg = "Enquiry Activity Added Successfully";
            //header("Location: view-enqry.php?id=$enqryId");    
        }
        $tempEnqryActivityDAO->addMailRefInEnquiryActivity($activityId, $clientEmail, $allocateMemberEmail, $referenceNum);
        $tempEnqryActivityDAO->addActivityInSendEmailTable($clientEmail, $allocateMemberEmail, $activityId, $_POST['enqryId'], "Enqry", $referenceNum);
        header("Location: view-enqry.php?id=$enqryId");
        
}
?>
        <?php 
        include 'include/head_tag_header.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--<title>Utharaprint : Add Enquiry Activity</title>-->
<script type="text/javascript" src="js/validate.js"></script>
<script src="ckeditor/ckeditor.js"></script>

<script type="text/javascript">
 
  function submitEmailDraft()
  {
      //alert('hi');
      if(document.getElementById('msgSubject').value=='')
      {
          alert('Please Enter Email Subject.');
          document.getElementById('msgSubject').focus();
          return false;
      }
  document.getElementById('EmailDraft').value="Send";
  document.memberForm.submit();    
  }
  
    
    </script>
<script type="text/javascript" src="js/additional.js"></script>

</head>
<body>
<div  id="wrap">
	<div id="header">
    <div class="header-inner">
    	<div class="profile-dtl">
    	<?php 
	             if($_SESSION['photoPath']!=NULL)
	             {
	                    echo "<img src='upload/member-image/".$_SESSION['photoPath']."' alt='Manage Profile'  height='65' />";
	         	 }
	             else 
	             {
	                    echo "<img src='images/profile-img.png' width='65' height='65' alt='Manage Profile' />";
	             } 
	    ?>
    	<h1>Enquiries</h1><p><?php echo $firstName; ?> <?php echo $memberPost; ?><!-- <a href="logout.php" title="log out">log out</a>--> 
                <?php include 'include/logout-sidebar.php'; ?> </p></div>
        &nbsp;
   
    <div class="clr"></div>
    </div>
   
    <div id="middle">
    	<div class="team-page-frame">
        	<div class="teamedit-top-btn"><a href="manage-enquiries.php" title="Go to Back" style="border-radius:0px 4px 4px 0px;">Go to Back</a></div>
        <?php include 'include/header.php'; ?>
        </div>
    	<div class="middle-inner">
                <div class="edit-frm-frame"><?php if($message!=''){ echo $message;} ?>
            	<div class="frm-frame-top">
            	<form name="memberForm" id="memberForm" action="<?php $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
                	<input type="hidden" name="action" value="Send" />
                         <input type="hidden" name="enqryId" value="<?php echo $tempEnquiriesVO->getEnqryId(); ?>" />
                         <input type="hidden" name="clientEmail" value="<?php echo $tempEnquiriesVO->getEnqryEmail(); ?>" />
                         <input type="hidden" name="enqry" value="<?php echo $tempEnquiriesVO->getEnqryId(); ?>" />
                         <input type="hidden" name="memberId" value="<?php echo $_POST['memberId'];?>" />
                          <input type="hidden" name="allocateMemberEmail" value="<?php echo $allocatMemberEmail;?>" />
                          <input type="hidden" name="EmailDraft" id="EmailDraft"  />
                         <input type="hidden" name="activityType" id="activityType"  />
                         <input type="hidden" name="selectCustom" id="selectCustom"  />
                	  	<div class="frame-top-rft">
                    	<ul>
                        	<li><label for="Telephone" style="width:150px;">Activity Date :</label><span><span><?php echo date("d/m/Y"); ?></span></span></li>
                        	<li><label for="Mobile" style="width:150px;">Activity Type :</label> 
						    <?php
	       							echo Dropdown::getActivityTypeList("",$activityType,"style='width:150px;'");
	 						?>
	 						</li>
                           
                            <li><label for="Mobile" style="width:150px;">Enquiry Contact Name :</label> 
						    <?php
	       							echo $enquiryContactName;
	 						?>
	 						</li>
                                 <li><label for="Mobile" style="width:150px;">Email Address :</label> 
						    <?php
	       							echo $emailAddress;
	 						?>
	 						</li>
                            
                           
                            <li><label for="Mobile" style="width:150px;">Subject :</label> 
                                <input type="test" name="msgSubject" id="msgSubject"  value="<?php echo $activitySubject;?>"style="background-color: #ffffff; border: 1px solid #84b8e7;color: #676767;font-size: 12px;font-weight: bold;height: 20px;text-indent: 5px;"/>
						    <?php
	       						
	 						?></li>
                            <br />
                             
                            <br />
                             <li><label for="Salesh Target">Activity Draft:</label> <label>
                                  
                             <!-- <textarea name="activityInfo" id="activityInfo" cols="50" rows="10"></textarea>-->
                                     <textarea class="ckeditor" id="editor"  name="activityInfo" >
                                         <?php  echo $activityInfo;?></textarea> 
                                 </label>
                            </li>
                            <br />
                            <li><label for="Mobile" style="width:150px;">Attach File :</label> 
                                <input type="file" name="attachFile" id="attachFile"  value="" style="background-color: #ffffff; border: 1px solid #84b8e7;color: #676767;font-size: 12px;font-weight: bold;height: 20px;text-indent: 5px;"/>
						    <?php
	       						
	 						?>
                            </li>
                            <br />
                            <div>
                            <div class="clr"></div>
                            <div align="left" style="padding:20px 10px 10px 140px;">
                                <input type="button" name="Submit" value="Send" class="sav-activity-btn" onclick="javascript:return submitEmailDraft();" />&nbsp;&nbsp;&nbsp;&nbsp;
                                <a href="view-enqry.php?id=<?php echo $tempEnquiriesVO->getEnqryId(); ?>" class="sav-activity-btn" style="line-height:20px;">Back</a>
                                </div>
                            </div>
                    	</ul>
                      <div class="upload-pic">&nbsp;</div>
                    </div>
                  </form>
              </div>
                <br /><br /><br /><br />
                &nbsp;&nbsp;&nbsp;&nbsp;
                <br /><br /><br /><br />
            </div>
        </div>
        <div class="clr"></div>
    </div>
    <div class="clr"></div>
    <?php include 'include/footer.php'; ?>
</div>
</body>
</html>
