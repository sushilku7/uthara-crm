<?php
ob_start();
session_start();
error_reporting (E_ALL ^ E_NOTICE);
if(isset($_POST['action']) && $_POST['action']=="login")
{
	$alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
	    for ($i = 0; $i < 8; $i++) 
	    {
	        $n = rand(0, strlen($alphabet)-1);
	        $pass[$i] = $alphabet[$n];
	    }
	    $newPass = implode("",$pass);
   
	$memberEmail = $_POST['user_name'];
	if(isset($_POST['comp_name']) && $_POST['comp_name']=='www.utharaprint.co.uk')
	{
	    $hostname = "localhost";		
		$database = "utharaprintco_utharaprintdb";
		$db_login = "utharaprintco_utharaprintuser";
		$db_pass = "js{)k,0G?U@B";

		//Set the DB conn
		$dbconn =@mysql_connect($hostname,$db_login,$db_pass) or die("Could not connect:". mysql_error() );
		//Set the db selected value
		$isDBSelected=mysql_select_db($database) or die("Could not select database". mysql_error());
		if($isDBSelected)
		{
		    //echo "connected";die();
		}
		else
		{
		    //echo "database not connect";die();
		}		
	   		
	   	$memberloginQuery = "select * from member_tbl where memberEmail='".$memberEmail."' ";   		 
		$result = mysql_query($memberloginQuery);
	    	$recordCount = mysql_num_rows($result);
	        //If number of records are one
	        if($recordCount==1)
	        {	
	        	  $row=mysql_fetch_array($result);
	        	  $memrId= $row['memberId'];
	        	  $memberName = $row['memberName'];
	        	  $tempArr = explode(' ', $memberName);
                  $firstName = $tempArr[0];
	        	  $password = $newPass;
	        	  $encPassword = md5($password);	        	 
	        	  $updatePassQuery = "UPDATE member_tbl SET memberPass='".$encPassword."' WHERE memberId='".$memrId."'";
			  	  $updatePassResult = mysql_query($updatePassQuery);
			  	  			  	  
			  	  $email_to = $memberEmail;
			          //$email_from = "sales@utharaprint.co.uk";
                  $email_from = "sales@utharaprint.co.uk";						
				  $email_subject = "Login details reminder";
				  //$headers  = "From: " . $email_from . "\r\n";
				  $headers  = "From: Utharaprint <".$email_from.">\r\n";
				  $headers .= "Reply-To: " . $email_from . "\r\n";
				  $headers .= "Content-type: text/html";
				  $currDate = date("d/m/Y h:i a");
				  $message  =  "<table width='700' border='0' cellspacing='0' cellpadding='0'>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Hi $firstName, </font></td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>				  
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Your new login details are below: </font></td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
									  				  </tr>
													  <tr>
													    <td align='left' valign='middle'><font face='Arial' size='2'><strong>Username:</strong></font></td>
                                                        <td align='left' valign='middle'><font face='Arial' size='2'>$email_to</font></td>
									 				  </tr>
									                  <tr>
									                     <td align='left' valign='middle' colspan='2'>&nbsp;</td>
									                  </tr>
									                  <tr>
									                     <td width='116' align='left' valign='middle'><em><font face='Arial' size='2'><strong>Password:</strong></font></em></td>
									                     <td width='584' align='left' valign='top'><em><font face='Arial' size='2'>$password</font></em> </td>
									                  </tr>                   
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Kind regards,</font></td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'><strong><a href='http://utharaprint-crm.online'>http://utharaprint-crm.online</a></strong></font>
                                                      </td>
													  </tr>
													  <tr>
													   <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
												</table>";
				  //ini_set("sendmail_from", $email_from);
				  //echo $message;die();
				  $msg=1;
				  $sent = mail($email_to, $email_subject, $message, $headers);				 
				  return true;
		     }
		     else
		     {		     	
		          return false;
	         }	   
				
	            
	          mysql_close();
			  
	            
	           
	        }
	   
	
	
	if(isset($_POST['comp_name']) && $_POST['comp_name']=='www.utharaprint.com.au')
	{
		//echo "australia";die();
	    $hostname = "localhost";		
		$database = "utharaprintco_utharaprintdb";
		$db_login = "utharaprintco_utharaprintuser";
		$db_pass = "js{)k,0G?U@B";

		//Set the DB conn
		$dbconn =@mysql_connect($hostname,$db_login,$db_pass) or die("Could not connect:". mysql_error() );
		//Set the db selected value
		$isDBSelected=mysql_select_db($database) or die("Could not select database". mysql_error());
		if($isDBSelected)
		{
		    //echo "connected";die();
		}
		else
		{
		    //echo "database not connect";die();
		}
		
	   	$memberloginQuery = "select * from member_tbl where memberEmail='".$memberEmail."' ";   		 
		$result = mysql_query($memberloginQuery);
	    	$recordCount = mysql_num_rows($result);
	        //If number of records are one
	        if($recordCount==1)
	        {	
	        	  $row=mysql_fetch_array($result);
	        	  $memrId= $row['memberId'];
	        	  $memberName = $row['memberName'];
	        	  $tempArr = explode(' ', $memberName);
                  $firstName = $tempArr[0];
	        	  $password = $newPass;
	        	  $encPassword = md5($password);	        	 
	        	  $updatePassQuery = "UPDATE member_tbl SET memberPass='".$encPassword."' WHERE memberId='".$memrId."'";
			  	  $updatePassResult = mysql_query($updatePassQuery);
			  	  			  	  
			  	  $email_to = $memberEmail;
			          //$email_from = "sales@utharaprint.co.uk";
                  $email_from = "sales@utharaprint.co.uk";						
				  $email_subject = "Login details reminder";
				  //$headers  = "From: " . $email_from . "\r\n";
				  $headers  = "From: Utharaprint <".$email_from.">\r\n";
				  $headers .= "Reply-To: " . $email_from . "\r\n";
				  $headers .= "Content-type: text/html";
				  $currDate = date("d/m/Y h:i a");
				  $message  =  "<table width='700' border='0' cellspacing='0' cellpadding='0'>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Hi $firstName, </font></td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>				  
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Your new login details are below: </font></td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
									  				  </tr>
													  <tr>
													    <td align='left' valign='middle'><font face='Arial' size='2'><strong>Username:</strong></font></td>
                                                        <td align='left' valign='middle'><font face='Arial' size='2'>$email_to</font></td>
									 				  </tr>
									                  <tr>
									                     <td align='left' valign='middle' colspan='2'>&nbsp;</td>
									                  </tr>
									                  <tr>
									                     <td width='116' align='left' valign='middle'><em><font face='Arial' size='2'><strong>Password:</strong></font></em></td>
									                     <td width='584' align='left' valign='top'><em><font face='Arial' size='2'>$password</font></em> </td>
									                  </tr>                   
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Kind regards,</font></td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'><strong><a href='http://utharaprint-crm.online'>http://utharaprint-crm.online</a></strong></font>
                                                      </td>
													  </tr>
													  <tr>
													   <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
												</table>";
				  //ini_set("sendmail_from", $email_from);
				  //echo $message;die();
				  $msg=1;
				  $sent = mail($email_to, $email_subject, $message, $headers);				 
				  return true;
		     } 
			 else
		     {		     	
		          return false;
	         }	   
				
	            
	          mysql_close();
	}
	
	if(isset($_POST['comp_name']) && $_POST['comp_name']=='www.bumboomprint.co.uk')
	{
	   $hostname = "localhost";		
		$database = "utharaprintco_utharaprintdb";
		$db_login = "utharaprintco_utharaprintuser";
		$db_pass = "js{)k,0G?U@B";

		//Set the DB conn
		$dbconn =@mysql_connect($hostname,$db_login,$db_pass) or die("Could not connect:". mysql_error() );
		//Set the db selected value
		$isDBSelected=mysql_select_db($database) or die("Could not select database". mysql_error());
		if($isDBSelected)
		{
		    //echo "connected";die();
		}
		else
		{
		    //echo "database not connect";die();
		}
		
	   	$memberloginQuery = "select * from member_tbl where memberEmail='".$memberEmail."' ";   		 
		$result = mysql_query($memberloginQuery);
	    	$recordCount = mysql_num_rows($result);
	        //If number of records are one
	        if($recordCount==1)
	        {	
	        	  $row=mysql_fetch_array($result);
	        	  $memrId= $row['memberId'];
	        	  $memberName = $row['memberName'];
	        	  $tempArr = explode(' ', $memberName);
                  $firstName = $tempArr[0];
	        	  $password = $newPass;
	        	  $encPassword = md5($password);	        	 
	        	  $updatePassQuery = "UPDATE member_tbl SET memberPass='".$encPassword."' WHERE memberId='".$memrId."'";
			  	  $updatePassResult = mysql_query($updatePassQuery);
			  	  			  	  
			  	  $email_to = $memberEmail;
			          //$email_from = "sales@utharaprint.co.uk";
                  $email_from = "sales@utharaprint.co.uk";						
				  $email_subject = "Login details reminder";
				  //$headers  = "From: " . $email_from . "\r\n";
				  $headers  = "From: Utharaprint <".$email_from.">\r\n";
				  $headers .= "Reply-To: " . $email_from . "\r\n";
				  $headers .= "Content-type: text/html";
				  $currDate = date("d/m/Y h:i a");
				  $message  =  "<table width='700' border='0' cellspacing='0' cellpadding='0'>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Hi $firstName, </font></td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>				  
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Your new login details are below: </font></td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
									  				  </tr>
													  <tr>
													    <td align='left' valign='middle'><font face='Arial' size='2'><strong>Username:</strong></font></td>
                                                        <td align='left' valign='middle'><font face='Arial' size='2'>$email_to</font></td>
									 				  </tr>
									                  <tr>
									                     <td align='left' valign='middle' colspan='2'>&nbsp;</td>
									                  </tr>
									                  <tr>
									                     <td width='116' align='left' valign='middle'><em><font face='Arial' size='2'><strong>Password:</strong></font></em></td>
									                     <td width='584' align='left' valign='top'><em><font face='Arial' size='2'>$password</font></em> </td>
									                  </tr>                   
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Kind regards,</font></td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'><strong><a href='http://utharaprint-crm.online'>http://utharaprint-crm.online</a></strong></font>
                                                      </td>
													  </tr>
													  <tr>
													   <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
												</table>";
				  //ini_set("sendmail_from", $email_from);
				  //echo $message;die();
				  $msg=1;
				  $sent = mail($email_to, $email_subject, $message, $headers);				 
				  return true;
		     }
			  else
		     {		     	
		          return false;
	         }	   
				
	            
	          mysql_close();
	}	
	if(isset($_POST['comp_name']) && $_POST['comp_name']=='www.utharaprint.sg')
	{
	$hostname = "localhost";		
		$database = "utharaprintco_utharaprintdb";
		$db_login = "utharaprintco_utharaprintuser";
		$db_pass = "js{)k,0G?U@B";

		//Set the DB conn
		$dbconn =@mysql_connect($hostname,$db_login,$db_pass) or die("Could not connect:". mysql_error() );
		//Set the db selected value
		$isDBSelected=mysql_select_db($database) or die("Could not select database". mysql_error());
		if($isDBSelected)
		{
		    //echo "connected";die();
		}
		else
		{
		    //echo "database not connect";die();
		}
		
	   	$memberloginQuery = "select * from member_tbl where memberEmail='".$memberEmail."' ";   		 
		$result = mysql_query($memberloginQuery);
	    	$recordCount = mysql_num_rows($result);
	        //If number of records are one
	        if($recordCount==1)
	        {	
	        	  $row=mysql_fetch_array($result);
	        	  $memrId= $row['memberId'];
	        	  $memberName = $row['memberName'];
	        	  $tempArr = explode(' ', $memberName);
                  $firstName = $tempArr[0];
	        	  $password = $newPass;
	        	  $encPassword = md5($password);	        	 
	        	  $updatePassQuery = "UPDATE member_tbl SET memberPass='".$encPassword."' WHERE memberId='".$memrId."'";
			  	  $updatePassResult = mysql_query($updatePassQuery);
			  	  			  	  
			  	  $email_to = $memberEmail;
			          //$email_from = "sales@utharaprint.co.uk";
                  $email_from = "sales@utharaprint.co.uk";						
				  $email_subject = "Login details reminder";
				  //$headers  = "From: " . $email_from . "\r\n";
				  $headers  = "From: Utharaprint <".$email_from.">\r\n";
				  $headers .= "Reply-To: " . $email_from . "\r\n";
				  $headers .= "Content-type: text/html";
				  $currDate = date("d/m/Y h:i a");
				  $message  =  "<table width='700' border='0' cellspacing='0' cellpadding='0'>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Hi $firstName, </font></td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>				  
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Your new login details are below: </font></td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
									  				  </tr>
													  <tr>
													    <td align='left' valign='middle'><font face='Arial' size='2'><strong>Username:</strong></font></td>
                                                        <td align='left' valign='middle'><font face='Arial' size='2'>$email_to</font></td>
									 				  </tr>
									                  <tr>
									                     <td align='left' valign='middle' colspan='2'>&nbsp;</td>
									                  </tr>
									                  <tr>
									                     <td width='116' align='left' valign='middle'><em><font face='Arial' size='2'><strong>Password:</strong></font></em></td>
									                     <td width='584' align='left' valign='top'><em><font face='Arial' size='2'>$password</font></em> </td>
									                  </tr>                   
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Kind regards,</font></td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'><strong><a href='http://utharaprint-crm.online'>http://utharaprint-crm.online</a></strong></font>
                                                      </td>
													  </tr>
													  <tr>
													   <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
												</table>";
				  //ini_set("sendmail_from", $email_from);
				  //echo $message;die();
				  $msg=1;
				  $sent = mail($email_to, $email_subject, $message, $headers);				 
				  return true;
		     }
			 else
		     {		     	
		          return false;
	         }	   
				
	            
	          mysql_close();
	}	
	if(isset($_POST['comp_name']) && $_POST['comp_name']=='www.utharadesigns.com')
	{
	$hostname = "localhost";		
		$database = "utharaprintco_utharaprintdb";
		$db_login = "utharaprintco_utharaprintuser";
		$db_pass = "js{)k,0G?U@B";

		//Set the DB conn
		$dbconn =@mysql_connect($hostname,$db_login,$db_pass) or die("Could not connect:". mysql_error() );
		//Set the db selected value
		$isDBSelected=mysql_select_db($database) or die("Could not select database". mysql_error());
		if($isDBSelected)
		{
		    //echo "connected";die();
		}
		else
		{
		    //echo "database not connect";die();
		}
		
	   	$memberloginQuery = "select * from member_tbl where memberEmail='".$memberEmail."' ";   		 
		$result = mysql_query($memberloginQuery);
	    	$recordCount = mysql_num_rows($result);
	        //If number of records are one
	        if($recordCount==1)
	        {	
	        	  $row=mysql_fetch_array($result);
	        	  $memrId= $row['memberId'];
	        	  $memberName = $row['memberName'];
	        	  $tempArr = explode(' ', $memberName);
                  $firstName = $tempArr[0];
	        	  $password = $newPass;
	        	  $encPassword = md5($password);	        	 
	        	  $updatePassQuery = "UPDATE member_tbl SET memberPass='".$encPassword."' WHERE memberId='".$memrId."'";
			  	  $updatePassResult = mysql_query($updatePassQuery);
			  	  			  	  
			  	  $email_to = $memberEmail;
			          //$email_from = "sales@utharaprint.co.uk";
                  $email_from = "sales@utharaprint.co.uk";						
				  $email_subject = "Login details reminder";
				  //$headers  = "From: " . $email_from . "\r\n";
				  $headers  = "From: Utharaprint <".$email_from.">\r\n";
				  $headers .= "Reply-To: " . $email_from . "\r\n";
				  $headers .= "Content-type: text/html";
				  $currDate = date("d/m/Y h:i a");
				  $message  =  "<table width='700' border='0' cellspacing='0' cellpadding='0'>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Hi $firstName, </font></td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>				  
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Your new login details are below: </font></td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
									  				  </tr>
													  <tr>
													    <td align='left' valign='middle'><font face='Arial' size='2'><strong>Username:</strong></font></td>
                                                        <td align='left' valign='middle'><font face='Arial' size='2'>$email_to</font></td>
									 				  </tr>
									                  <tr>
									                     <td align='left' valign='middle' colspan='2'>&nbsp;</td>
									                  </tr>
									                  <tr>
									                     <td width='116' align='left' valign='middle'><em><font face='Arial' size='2'><strong>Password:</strong></font></em></td>
									                     <td width='584' align='left' valign='top'><em><font face='Arial' size='2'>$password</font></em> </td>
									                  </tr>                   
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'>Kind regards,</font></td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
													  <tr>
													    <td align='left' valign='middle' colspan='2'><font face='Arial' size='2'><strong><a href='http://utharaprint-crm.online'>http://utharaprint-crm.online</a></strong></font>
                                                      </td>
													  </tr>
													  <tr>
													   <td align='left' valign='middle' colspan='2'>&nbsp;</td>
													  </tr>
												</table>";
				  //ini_set("sendmail_from", $email_from);
				  //echo $message;die();
				  $msg=1;
				  $sent = mail($email_to, $email_subject, $message, $headers);
						
				  return true;
		     }
			  else
		     {		     	
		          return false;
	         }	   
				
	            
	          mysql_close();
	}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Uthara Print</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1' name='viewport'>
    <link rel="shortcut icon" href="img/admin.png"/>
    <!--start global css-->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="vendors/themify-icons.css" />
    <!-- end of global css -->
    <!--start plugin css -->
    <link rel="stylesheet" href="vendors/bootstrapValidator.min.css">
    <!--end plugin css -->
    <link type="text/css" rel="stylesheet" href="css/custom.css" />
    <link type="text/css" rel="stylesheet" href="css/pages/login.css" />
<script>
function checkDomainSelection()
{
	if(document.getElementById('comp_name').value=='')
	{
		alert('Please select domain');
		return false;
	}
	else
	{
		return true;
	}
	
}
</script>
</head>

<body class="login_screen">
<!--<div class="preloader">
    <div class="preloader_img">
        <img src="img/loader.gif" class="pre_img" alt="loading...">
    </div>
</div>-->
<!--Start wrapper-->
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-4 col-md-6">
            <div class="login_box p-3">
            <div class="row m-t-20">
                <div class="col-lg-12 text-center">
                    
                    <h1 class="text-white m-t-20"><img src='img/logo.png'  /></h1></div>
                </div>

            <div class="m-t-15">
                <form action=""  method="post" autofocus="off" id="login_from">
				<?php if($msg!=''){?><div class="col-md-12 btn btn-danger"> <?php echo "Password sent on mail,Please check your Email.";?></div><br><br><?php } ?>
				<div class="form-group ">
                        <div class="input-group ">
						<select name='comp_name' id='comp_name' class="form-control" style="background:#000;" >
						<option value=''>Please Select domain</option>
						<option value='www.utharaprint.co.uk'>www.utharaprint.co.uk</option>
						<option value='www.utharaprint.com.au'>www.utharaprint.com.au</option>
						<option value='www.bumboomprint.co.uk'>www.bumboomprint.co.uk</option>
						<option value='www.utharaprint.sg'>www.utharaprint.sg</option>
						<option value='www.utharaprint.sg'>www.utharadesigns.com</option>

						</select>
                       </div>
                    </div>
                    <div class="form-group ">
                        <div class="input-group ">
                            <span class="input-group-addon">
                                <i class="ti-user"></i>
                            </span>
                            <input type="text" name="user_name" class="form-control" placeholder="Enter your email id" autofocus="off"  autocomplete='off' required>
                        </div>
                    </div>
						<input type="hidden" name="action" value="login">
                   
                    <div class="text-center login_bottom">
                        <button type="submit" class="btn btn-success btn-block b_r_20 m-t-10 m-r-20" onclick="javascript: return checkDomainSelection()">Reset Password</button>
                    </div><br >

                   <div class="text-center login_bottom">
                        <a href="index.php" class="btn btn-success btn-block b_r_20 m-t-10 m-r-20" >Back</a>
                    </div><br >

                </form>
            </div>

              
            </div>
        </div>
    </div>
</div>
<?php

?>
<!-- ./wrapper -->
<script>

</script>
</html>
