<?php
session_start();
error_reporting (E_ALL ^ E_NOTICE);
include('includes/top_header.php');
$tempMemberDAO = new MemberDAO();

if(isset($_POST['action']) && $_POST['action']=="remind-me")
{
	if($tempMemberDAO->genrateNewPassword($_POST['memberEmail']))
	{		
		    $msg =  "1";
	}
	else 
	{
		    $msg =  "2";
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Utharaprint - Remind Me</title>
<?php 
        include 'include/head_tag_header.php';
?>
<script type="text/javascript" src="js/additional.js"></script>

</head>
<body class="login-body-bg">
<div class="login-wrap">	
    <?php include 'include/header-right.php'; ?>
    <div class="clr"></div>
    <div class="login-container">
    	<div class="login-content">
        	<form name="login_form" id="login_form" action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" enctype="application/x-www-form-urlencoded" >
            	<h1>Remind me...</h1>
                <div class="login-fields">
                	<p>Please enter your email address</p>
                    <div class="nml-msg">
				   <?php 
                       if(isset($msg) && $msg=="1") 
                            echo "<font color='green'>Reminder sent successfully</font>"; 
                       if(isset($msg) && $msg=="2") 
                            echo "<font color='red'>Unable to sent reminder</font>"; 
                   ?>
                   </div>
                    <input type="hidden" name="action" id="action" value="remind-me" />
                    <div class="fields">
                    	<label for="username">Username</label>
                        <input name="memberEmail" id="memberEmail" class="login email-field" type="text" placeholder="Email address" value="">
                    </div>                    
                </div>
                <div class="login-actions"><input type="submit" class="button btn btn-success btn-large" value="Reset" name="submit"  /></div>
            </form>
            <div class="clr"></div>
        </div>
    </div>
</div>
</body>
</html>