"use strict";
$(document).ready(function(){

    $(".fancybox").fancybox();

});
