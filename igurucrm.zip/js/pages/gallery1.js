"use strict";
$(document).ready(function(){
    $("#gallery1").unitegallery();

});
