"use strict";
$(document).ready(function () {
    $('#delete_user').DataTable({
        "ordering": true,
        "info": true,
        "searching": false
    });
});